
<div data-objectid="<?=$object_id;?>" class="module clearfix cluster classPath-lattice_modules_Cluster <?=(isset($object_type_name))? $object_type_name:null;?>">
	<label><?=$label;?></label>
	<div class="wrapper">
		<?=$html;?>
	</div>
</div>
