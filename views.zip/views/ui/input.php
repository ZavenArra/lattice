<div class="ui-Input <?=$class;?>" data-field="<?=$name;?>">
	<?if (isset($label)):?><label><?=$label;?></label><?endif;?>
	<input type="text" name="<?=$name;?>" value="<?=$value;?>" size="<?=$size;?>" />
</div>
