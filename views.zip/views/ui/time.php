<div class="ui-TimePicker <?=$class;?>" data-field="<?=$name;?>">
	<?if (isset($label)):?>
		<label><?=$label;?></label>
	<?endif;?>
<input type="text" value="<?=substr($value, 0, 5);?>"></input>
</div>
