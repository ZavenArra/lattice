<div class="ui-DatePicker <?=$class;?>" data-field="<?=$name;?>">
	<?if (isset($label)):?>
		<label><?=$label;?></label>
	<?endif;?>
	<input type="text" value="<?=$value;?>" />
</div>
