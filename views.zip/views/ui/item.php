<div class="ui-Input">
	<label><?=$label;?></label>
	<input type="text" name="<?=$item_name?>" value="<?=$item_name?>" disabled="disabled" />
</div>


	
