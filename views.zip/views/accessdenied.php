<div style="position:absolute;background-color:#FFC0C0;border:2px solid #FF0000;left:10%;top:50px;padding:20px;width:80%;text-align:center">
	<h1 style="margin-top:0px">Access Denied</h1>
	You do not have permission to access this area of the site.
  <br><br>
  <a href="<?=url::base();?>auth/logout">Click here to logout and login as a different user</a>
</div>
