<div class="modalContainer">
	<div class="header container_12">
		<h3>Lattice is now installed</h3>
	</div>
	<div class="modal container_12">
		<a class="button" href="<?=url::base('http');?>cms">Go to the CMS</a>
	</div>
</div>