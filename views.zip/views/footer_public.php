This is the default public footer
