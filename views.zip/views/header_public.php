This is the default public header
