<form action="<?=url::base();?>csv/importCSVFile" method="POST" enctype="multipart/form-data">
   <input type="file" name="upload" />
   <input type="submit"/>
</form>