<div class="modalContainer">
	<div class="header container_12">
		<h3>Lattice is Not Installed</h3>
	</div>
	<div class="modal container_12">
  <a class="button" href="<?php echo url::site('setup'); ?>">Install lattice now</a>
	</div>
</div>
