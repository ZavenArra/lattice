asdsadadsads
<li data-objectid="<?=$object->id;?>">
  <div class="itemControls">
    <a class="associate" href="#">Associate This!</a>
    <a class="dissociate" href="#">Dissociate This!</a>
  </div>
  <h4><?=$object->title;?></h4>
</li>
