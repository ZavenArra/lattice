Username: <?=$username;?>

Password: <?=$password;?>
