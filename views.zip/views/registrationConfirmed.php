<div class="modalContainer">
	<div class="header container_12">
		<h3>Your registration has been confirmed.</h3>
	</div>
	<div class="modal container_12">
		<div class="content login">
			<p><a class="button" href="<?=url::base('http');?>">You may proceed to the site.</a></p>
		</div>
	</div>
</div>