<div id="<?=$instance;?>" class="module usermanagement controller-<?=$class;?> classPath-lattice_modules_UserManagement sortable-true clearFix">

	<label class='listLabel'>Manage users</label>

	<div class="listcontrols controls top clearFix"><a href="#" class="addItem button">Add a User</a></div>

	<ul class="listing">
		<?=$items;?> 
	</ul>

  <div class="listcontrols controls bottom clearFix"><a href="#" class="addItem button">Add a User</a></div>

</div>


