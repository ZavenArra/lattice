<div class="modalContainer">
	<div class="header container_12">
		<h3>Confirmation Required</h3>
	</div>
	<div class="modal container_12">
		<div class="content login">
			<p>A message has been sent to the email address you provided.  Please click the link in the email to confirm your registration.</p>
		</div>
	</div>
</div>


